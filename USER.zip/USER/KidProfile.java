package USER;

import java.util.List;
import CONTENT.Genre;

public class KidProfile implements Profile{
    private String username;
    private List<Genre> preferences;
    
    public KidProfile(String username, List<Genre> preferences){
        this.username = username;
        this.preferences = preferences;
    }

    @Override
    /* Gives the profile's username */
    public String getUsername() {
        return username;
    }

    @Override
    /* Gives the profile's preferences */
    public List<Genre> getPreferences(){ 
        return preferences;
    }
}
