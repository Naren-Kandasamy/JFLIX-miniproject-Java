package USER;
import java.util.List;
import CONTENT.Genre;

public class ParentProfile implements Profile{
    private String username;
    private List<Genre> preferences;

    ParentProfile(String username, List<Genre> preferences){
        this.username = username;
        this.preferences = preferences;
    }

    @Override
    /* Returns username */
    public String getUsername(){
        return username;
    }

    @Override
    /* Returns preferences */
    public List<Genre> getPreferences(){
        return preferences;
    }
}
