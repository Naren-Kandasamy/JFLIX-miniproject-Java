package USER;
import CORE.Identifiable; 

public class User implements Identifiable{
    private String id;
    Profile profile;

    public User(String id, Profile profile){
        this.id = id;
        this.profile = profile;
    }

    public String getID(){
        return id;
    }
    
    public Profile getProfile(){
        return profile;
    }

    public void setProfile(Profile profile){
        this.profile = profile;
    }
}
